var app = angular.module('quizApp', ['firebase']);

app.directive('quiz', function(quizFactory,$firebaseArray) {
	return {
		restrict: 'AE',
		scope: {},
		templateUrl: 'QuizTemplate.html',
		link: function(scope, elem, attrs) {
			scope.start = function() {
				scope.id = 0;
				scope.quizOver = false;
				scope.inProgress = true;
				scope.getQuestion();
			};

			scope.reset = function() {
				scope.inProgress = false;
				scope.score = 0;
			}

			scope.getQuestion = function(response) {
			
			//var q=[];
			console.log("scope"+scope.id);
		//	console.log("its like"+$.get(quizFactory.getQuestion(scope.id)));
				var q= $.get(quizFactory.getQuestion(scope.id));
				console.log(q);  
				//var q = Array.prototype.slice.call(q1, 0);
				
				
 
				if(q) {
					scope.question = q.question;
					scope.options = q.options;
					scope.answer = q.answer;
					scope.answerMode = true;
				} else {
					scope.quizOver = true;
				}
			};

			scope.checkAnswer = function() {
				if(!$('input[name=answer]:checked').length) return;

				var ans = $('input[name=answer]:checked').val();

				if(ans == scope.options[scope.answer]) {
					scope.score++;
					scope.correctAns = true;
				} else {
					scope.correctAns = false;
				}

				scope.answerMode = false;
			};

			scope.nextQuestion = function() {
				scope.id++;
				scope.getQuestion();
			}

			scope.reset();
		}
	}
});

app.factory('quizFactory',['$firebaseArray',function($firebaseArray) {
	/* var questions = [
		{
			question: "Which is the largest country in the world by population?",
			options: ["India", "USA", "China", "Russia"],
			answer: 2
		},
		{
			question: "When did the second world war end?",
			options: ["1945", "1939", "1944", "1942"],
			answer: 0
		},
		{
			question: "Which was the first country to issue paper currency?",
			options: ["USA", "France", "Italy", "China"],
			answer: 3
		},
		{
			question: "Which city hosted the 1996 Summer Olympics?",
			options: ["Atlanta", "Sydney", "Athens", "Beijing"],
			answer: 0
		},
		{	
			question: "Who invented telephone?",
			options: ["Albert Einstein", "Alexander Graham Bell", "Isaac Newton", "Marie Curie"],
			answer: 1
		}
	]; */
	
	 
  
  return {
		getQuestion: function(id) {
			var refAgain1=new Firebase("https://luminous-fire-5434.firebaseio.com/CADPQuiz");
    	
	refAgain1.on("value", function(snap) {
	var questions = snap.val();
	console.log(questions);
/*var myArr = Array.prototype.slice.call(questions, 0);
		//console.log(myArr[0]);
		
		var arreyM = [];
		//console.log(myArr[0].Question);
 for (var i = 0; i < myArr.length; i++) {
	 arreyM [i] = {}
      arreyM[i]['Question']= myArr[i].Question;
      arreyM[i]['Answer']= myArr[i].Answer
      arreyM[i]['Options'] =  myArr[i].Options; 
	  arreyM[i]['ID'] =  myArr[i].ID; 
 }
 */



 	if(id < 19 ) {
		
		
			 
										console.log("inside if");
										console.log(questions[id]);
										return questions[id];
									} 
									else
									
									 {
										 
										 console.log("inside else");
										return false;
									}
									});
		}
		
	
	};
	
	
	
}]);