angular.module('F1FeederApp', [
  'F1FeederApp.controllers'
]);
// JavaScript Document